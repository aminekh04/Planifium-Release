package com.diro.ift2255;

public class TestJava {
    public static void main(String[] args) {
        System.out.println("OK Java");
    }
}

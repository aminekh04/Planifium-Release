package com.diro.ift2255.controller;

import com.diro.ift2255.model.Opinion;
import com.diro.ift2255.service.OpinionService;
import io.javalin.http.Context;

import java.util.Map;

public class OpinionController {

    private static final OpinionService service = new OpinionService();

    // POST /api/opinions
    public static void addOpinion(Context ctx) {

        Opinion opinion = ctx.bodyAsClass(Opinion.class);

        try {
            service.addOpinion(opinion);
            ctx.status(201).json(Map.of("status", "ok"));
        } catch (IllegalArgumentException e) {
            ctx.status(400).json(Map.of("error", e.getMessage()));
        }
    }

    // GET /api/opinions?course_code=IFT2255
    public static void getOpinions(Context ctx) {

        String courseCode = ctx.queryParam("course_code");
        ctx.json(service.getOpinions(courseCode));
    }
}

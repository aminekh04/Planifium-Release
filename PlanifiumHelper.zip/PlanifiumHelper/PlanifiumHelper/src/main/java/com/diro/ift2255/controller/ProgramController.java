package com.diro.ift2255.controller;

import com.diro.ift2255.service.ProgramService;
import io.javalin.http.Context;

import java.util.Map;

public class ProgramController {

    private static final ProgramService programService =
            new ProgramService();

    public static void getProgramCourses(Context ctx) {

        String programId = ctx.pathParam("id");

        ctx.json(
                Map.of(
                        "programId", programId,
                        "courses",
                        programService.getCoursesForProgram(programId)
                )
        );
    }
}

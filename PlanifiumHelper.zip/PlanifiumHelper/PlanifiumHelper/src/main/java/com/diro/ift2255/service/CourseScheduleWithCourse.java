package com.diro.ift2255.service;

import com.diro.ift2255.model.CourseSchedule;

public class CourseScheduleWithCourse {

    private String courseId;
    private String section;
    private String activityType;
    private String day;
    private String startTime;
    private String endTime;

    public CourseScheduleWithCourse(
            String courseId,
            CourseSchedule schedule
    ) {
        this.courseId = courseId;
        this.section = schedule.getSection();
        this.activityType = schedule.getActivityType();
        this.day = schedule.getDay();
        this.startTime = schedule.getStartTime();
        this.endTime = schedule.getEndTime();
    }

    public String getCourseId() { return courseId; }
    public String getSection() { return section; }
    public String getActivityType() { return activityType; }
    public String getDay() { return day; }
    public String getStartTime() { return startTime; }
    public String getEndTime() { return endTime; }
}
